package com.example.quatroabas // troque pelo package do seu projeto

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private val defaults = listOf(
        "https://pt.wikipedia.org",
        "https://www.openstreetmap.org",
        "https://example.com",
        "https://duckduckgo.com"
    )
    private val prefs by lazy { getSharedPreferences("abas", MODE_PRIVATE) }

    private val panes = mutableListOf<LinearLayout>()
    private val rows = mutableListOf<LinearLayout>()
    private val webs = mutableListOf<WebView>()
    private val maxButtons = mutableListOf<Button>()
    private var maximized = -1
    private var focused = 0

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        repeat(2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
            rows.add(row)
        }

        for (i in 0 until 4) {
            val url = prefs.getString("url$i", defaults[i]) ?: defaults[i]

            val edit = EditText(this).apply {
                setText(url)
                setSingleLine()
                textSize = 12f
                imeOptions = EditorInfo.IME_ACTION_GO
            }
            val go = Button(this).apply { text = "Ir"; minWidth = 0; minimumWidth = 0 }
            val max = Button(this).apply { text = "⤢"; minWidth = 0; minimumWidth = 0 }
            maxButtons.add(max)

            val bar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
                addView(go, LinearLayout.LayoutParams(-2, -2))
                addView(max, LinearLayout.LayoutParams(-2, -2))
            }

            val web = WebView(this).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadWithOverviewMode = true
                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                        edit.setText(u)
                        prefs.edit().putString("url$i", u).apply()
                    }
                }
                setOnTouchListener { _, _ -> focused = i; false }
                loadUrl(url)
            }
            webs.add(web)

            val navigate = {
                var u = edit.text.toString().trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
                    web.loadUrl(u)
                    focused = i
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                        .hideSoftInputFromWindow(edit.windowToken, 0)
                }
            }
            go.setOnClickListener { navigate() }
            edit.setOnEditorActionListener { _, _, _ -> navigate(); true }
            max.setOnClickListener { toggleMax(i) }

            val pane = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(bar, LinearLayout.LayoutParams(-1, -2))
                addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            panes.add(pane)
            rows[i / 2].addView(pane, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(2, 2, 2, 2) })
        }

        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val w = webs[focused]
                when {
                    maximized >= 0 -> toggleMax(maximized)
                    w.canGoBack() -> w.goBack()
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
    }

    private fun toggleMax(i: Int) {
        val on = maximized != i
        maximized = if (on) i else -1
        for (p in panes.indices) {
            panes[p].visibility = if (!on || p == i) View.VISIBLE else View.GONE
            maxButtons[p].text = if (on && p == i) "⤡" else "⤢"
        }
        rows.forEachIndexed { r, row ->
            row.visibility = if (!on || r == i / 2) View.VISIBLE else View.GONE
        }
        focused = i
    }

    override fun onPause() { webs.forEach { it.onPause() }; super.onPause() }
    override fun onResume() { super.onResume(); webs.forEach { it.onResume() } }
    override fun onDestroy() { webs.forEach { it.destroy() }; super.onDestroy() }
}
